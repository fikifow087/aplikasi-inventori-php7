<?php
$koneksi = mysqli_connect("localhost", "root", "", "inv-barang2"); // provide all four parameters
if (!$koneksi) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
