<!DOCTYPE html>
<html>
<head>
    <title>Login | Inventory Barang</title> </head>

<!-- CSS -->
<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>

<body>
<div class="body-layout">
<h2 class="judul">LOGIN <br> INVENTORY BARANG</h2>
    <form action="login.php" method="post">
        <input type="text" name="username" placeholder="Username" class="text-input" autofocus>
        <input type="password" name="password" placeholder="Password"" class="text-input">
        <center>
        <input type="reset" value="Clear" class="clear" /> <input type="submit" name="login" value="Log In" class="tombol">
        </center>
    </form>
</div>
</body>
</html>