# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

## [1.1] - 2019-07-20
### Added
- CHANGELOG.md

### Changed
- Memperbaiki judul halaman, pada halaman Edit Data Barang
- Memperbarui screenshot input-data-barang.png

## [1.0] - 2019-07-14
### Added
- First Release

[Unreleased]: https://github.com/muhrizki1996/aplikasi-inventory-barang-sederhana-php/tree/712a29b1a213e14fbe61965dda74585152af14aa
[1.1]: https://github.com/muhrizki1996/aplikasi-inventory-barang-sederhana-php/compare/master@%7B1day%7D...master
[1.0]: https://github.com/muhrizki1996/aplikasi-inventory-barang-sederhana-php/releases/tag/1.0